<?php

use App\Livewire\Form;

\Illuminate\Support\Facades\Route::get('form', Form::class);
